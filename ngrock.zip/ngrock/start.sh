#!/bin/sh 
/Users/jack/Documents/software/ngrock/ngrok -config=ngrok.cfg -subdomain 16web 8360
